
namespace SM.Store.Api.Contracts.Models
{
    using System;
    
    public class ErrorMessage
    {
        public string Code { get; set; }
        public string Message { get; set; }
               
    }

}
