﻿using System;

namespace SM.Store.Api.Contracts.Models
{
    public class ProductStatusType
    {
        public int StatusCode { get; set; }
        public string Description { get; set; }        
    }
}
