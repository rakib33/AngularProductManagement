﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using System.Web.Http.ModelBinding;
using Newtonsoft.Json;
using SM.Store.Api.BLL;
using SM.Store.Api.Common;
using SM.Store.Api.DAL;
using SM.Store.Api.Models;

namespace SM.Store.Api.Controllers
{    
    [RoutePrefix("api/products")]
    public class ProductsController : ApiController
    {
        [Route("~/api/getproductList")]
        public PagedProductListResponse GetProductList([ModelBinder(typeof(FieldValueModelBinder))] GetProductsBySearchRequest request)
        {
            var resp = new PagedProductListResponse();

            Models.ProductSearchField searchField = 0;
            string searchText = null;
            Decimal? priceLow = null;
            Decimal? priceHigh = null;
            DateTime? dateFrom = null;
            DateTime? dateTo = null;
            if (request.ProductSearchFilter != null)
            {
                searchField = request.ProductSearchFilter.ProductSearchField;
                searchText = request.ProductSearchFilter.ProductSearchText;
            }
            if (request.PriceSearchFilter != null)
            {
                if (!String.IsNullOrEmpty(request.PriceSearchFilter.SearchPriceLow)) priceLow = Convert.ToDecimal(request.PriceSearchFilter.SearchPriceLow);
                if (!String.IsNullOrEmpty(request.PriceSearchFilter.SearchPriceHigh)) priceHigh = Convert.ToDecimal(request.PriceSearchFilter.SearchPriceHigh);
            }
            if (request.DateSearchFilter != null)
            {
                if (!String.IsNullOrEmpty(request.DateSearchFilter.SearchDateFrom)) dateFrom = Convert.ToDateTime(request.DateSearchFilter.SearchDateFrom);
                if (!String.IsNullOrEmpty(request.DateSearchFilter.SearchDateTo)) dateTo = Convert.ToDateTime(request.DateSearchFilter.SearchDateTo);
            }
            int totalCount = 0;
            int newPageIndex = -1;

            IProductBS bs = default(IProductBS);
            //IProductBS prodBs = DIFactoryDesigntime.GetInstance<IProductBS>();
            //try
            //{
            bs = DIFactoryDesigntime.GetInstance<IProductBS>();
            //}
            //catch (Exception ex)
            //{
            //    var msg = ex.Message;
            //}

            //IProductRepository productRepo = new ProductRepository(new StoreDataModelUnitOfWork());
            IEnumerable<ProductCM> rtnList = bs.GetProductList(searchField, searchText,
                       priceLow, priceHigh, dateFrom, dateTo, request.StatusCode, request.PaginationRequest, 
                       out totalCount, out newPageIndex);
            resp.Products.AddRange(rtnList);
            //Test get json:
            //var output = JsonConvert.SerializeObject(resp.Products);

            resp.TotalCount = totalCount;
            return resp;
        }

        [Route("~/api/getproductlist_p")]
        public PagedProductListResponse Post_GetProductList([FromBody] GetProductsBySearchRequest request)
        {
            var resp = new PagedProductListResponse();

            Models.ProductSearchField searchField = 0;
            string searchText = null;
            Decimal? priceLow = null;
            Decimal? priceHigh = null;
            DateTime? dateFrom = null;
            DateTime? dateTo = null;
            IProductBS bs = DIFactoryDesigntime.GetInstance<IProductBS>();

            if (request.NewProductIds != null && request.NewProductIds.Count > 0)
            {
                //For refresh data with newly added products.                
                IList<Models.ProductCM> rtnList = bs.GetProductListNew(request.NewProductIds);
                resp.Products.AddRange(rtnList);
            }
            else
            {
                if (request.ProductSearchFilter != null)
                {
                    searchField = request.ProductSearchFilter.ProductSearchField;
                    searchText = request.ProductSearchFilter.ProductSearchText;
                }
                if (request.PriceSearchFilter != null)
                {
                    if (!String.IsNullOrEmpty(request.PriceSearchFilter.SearchPriceLow)) priceLow = Convert.ToDecimal(request.PriceSearchFilter.SearchPriceLow);
                    if (!String.IsNullOrEmpty(request.PriceSearchFilter.SearchPriceHigh)) priceHigh = Convert.ToDecimal(request.PriceSearchFilter.SearchPriceHigh);
                }
                if (request.DateSearchFilter != null)
                {
                    if (!String.IsNullOrEmpty(request.DateSearchFilter.SearchDateFrom)) dateFrom = Convert.ToDateTime(request.DateSearchFilter.SearchDateFrom);
                    if (!String.IsNullOrEmpty(request.DateSearchFilter.SearchDateTo)) dateTo = Convert.ToDateTime(request.DateSearchFilter.SearchDateTo);
                }
                        
                int totalCount = 0;
                int newPageIndex = -1;
                                
                IList<Models.ProductCM> rtnList = bs.GetProductList(searchField, searchText,
                                        priceLow, priceHigh, dateFrom, dateTo, request.StatusCode, request.PaginationRequest,
                                        out totalCount, out newPageIndex);
                resp.Products.AddRange(rtnList);
                resp.TotalCount = totalCount;
                resp.newPageIndex = newPageIndex;
            }
            return resp;
        }

        [Route("~/api/getpagedproductlist")]
        public Models.PagedProductListResponse Post_GetPagedProductList([FromBody] Models.PagedProductListRequest request)
        {
            var resp = new Models.PagedProductListResponse();
            if (request == null)
            {
                return resp;
            }

            Models.ProductSearchField searchField = 0;
            string searchText = null;
            Decimal? priceLow = null;
            Decimal? priceHigh = null;
            DateTime? dateFrom = null;
            DateTime? dateTo = null;
            IProductBS bs = DIFactoryDesigntime.GetInstance<IProductBS>();

            if (request.NewProductIds != null && request.NewProductIds.Count > 0)
            {
                //For refresh data with newly added products.
                IList<Models.ProductCM> rtnList = bs.GetProductListNew(request.NewProductIds);
                resp.Products.AddRange(rtnList);
            }
            else
            {
                if (request.ProductSearchFilter != null)
                {
                    searchField = request.ProductSearchFilter.ProductSearchField;
                    searchText = request.ProductSearchFilter.ProductSearchText;
                }
                if (request.PriceSearchFilter != null)
                {
                    if (!String.IsNullOrEmpty(request.PriceSearchFilter.SearchPriceLow)) priceLow = Convert.ToDecimal(request.PriceSearchFilter.SearchPriceLow);
                    if (!String.IsNullOrEmpty(request.PriceSearchFilter.SearchPriceHigh)) priceHigh = Convert.ToDecimal(request.PriceSearchFilter.SearchPriceHigh);
                }
                if (request.DateSearchFilter != null)
                {
                    if (!String.IsNullOrEmpty(request.DateSearchFilter.SearchDateFrom)) dateFrom = Convert.ToDateTime(request.DateSearchFilter.SearchDateFrom);
                    if (!String.IsNullOrEmpty(request.DateSearchFilter.SearchDateTo)) dateTo = Convert.ToDateTime(request.DateSearchFilter.SearchDateTo);
                }

                int totalCount = 0;
                int newPageIndex = -1;

                IList<Models.ProductCM> rtnList = bs.GetProductList(searchField, searchText,
                                        priceLow, priceHigh, dateFrom, dateTo, request.StatusCode, request.PaginationRequest,
                                        out totalCount, out newPageIndex);
                resp.Products.AddRange(rtnList);
                resp.TotalCount = totalCount;
                resp.newPageIndex = newPageIndex;
            }
            //Test loader.
            //System.Threading.Thread.Sleep(3000);

            return resp;
        }

        [Route("~/api/getpagedproductlistbysp")]
        public Models.PagedProductListResponse Post_GetPagedProductListSp([FromBody] Models.PagedProductListRequest request)
        {
            var resp = new Models.PagedProductListResponse();
            if (request == null)
            {
                return resp;
            }

            IProductBS bs = DIFactoryDesigntime.GetInstance<IProductBS>();

            if (request.NewProductIds != null && request.NewProductIds.Count > 0)
            {
                //For refresh data with newly added products.
                IList<Models.ProductCM> rtnList = bs.GetProductListNew(request.NewProductIds);
                resp.Products.AddRange(rtnList);
            }
            else
            {
                var filterString = " ";
                var sortString = " ";

                //Build filter string with custom encoding.
                if (request.ProductSearchFilter != null && !string.IsNullOrEmpty(request.ProductSearchFilter.ProductSearchText))
                {
                    //If using Enum names: Enum.GetName(typeof(Models.ProductSearchField), request.ProductSearchFilter.ProductSearchField)
                    if (request.ProductSearchFilter.ProductSearchField == Models.ProductSearchField.CategoryId &&
                        Util.IsNumeric(request.ProductSearchFilter.ProductSearchText))
                    {
                        filterString += " AND " + "CategoryId = " + request.ProductSearchFilter.ProductSearchText;
                    }
                    else if (request.ProductSearchFilter.ProductSearchField == Models.ProductSearchField.CategoryName)
                    {
                        filterString += " AND " + "CategoryName LIKE &dapos;%" + request.ProductSearchFilter.ProductSearchText + "%&dapos;";
                    }
                    else if (request.ProductSearchFilter.ProductSearchField == Models.ProductSearchField.ProductId &&
                        Util.IsNumeric(request.ProductSearchFilter.ProductSearchText))
                    {
                        filterString += " AND " + "ProductId = " + request.ProductSearchFilter.ProductSearchText;
                    }
                    else if (request.ProductSearchFilter.ProductSearchField == Models.ProductSearchField.ProductName)
                    {
                        filterString += " AND " + "ProductName LIKE &dapos;%" + request.ProductSearchFilter.ProductSearchText + "%&dapos;";
                    }
                }
                if (request.PriceSearchFilter != null)
                {
                    if (!string.IsNullOrEmpty(request.PriceSearchFilter.SearchPriceLow) &&
                        Util.IsNumeric(request.PriceSearchFilter.SearchPriceLow))
                    {
                        filterString += " AND " + "UnitPrice >= " + request.PriceSearchFilter.SearchPriceLow;
                    }
                    if (!string.IsNullOrEmpty(request.PriceSearchFilter.SearchPriceHigh) &&
                        Util.IsNumeric(request.PriceSearchFilter.SearchPriceHigh))
                    {
                        filterString += " AND " + "UnitPrice <= " + request.PriceSearchFilter.SearchPriceHigh;
                    }
                }
                if (request.DateSearchFilter != null)
                {
                    if (!string.IsNullOrEmpty(request.DateSearchFilter.SearchDateFrom))
                    {
                        filterString += " AND " + "AvailableSince >= &dapos;" +
                            Convert.ToDateTime(request.DateSearchFilter.SearchDateFrom).ToString("yyyy-MM-dd") + "&dapos;";
                    }
                    if (!string.IsNullOrEmpty(request.DateSearchFilter.SearchDateTo))
                    {
                        filterString += " AND " + "AvailableSince <= &dapos;" +
                            Convert.ToDateTime(request.DateSearchFilter.SearchDateTo).ToString("yyyy-MM-dd") + "&dapos;";
                    }
                }
                if (request.StatusCode != null)
                {
                    filterString += " AND " + "StatusCode = " + request.StatusCode.Value;
                }
                if (request.PaginationRequest.SortList != null && request.PaginationRequest.SortList.Count > 0)
                {
                    foreach (var item in request.PaginationRequest.SortList)
                    {
                        if (sortString != " ") sortString += ", ";
                        sortString += item.SortBy + " " + item.SortDirection;
                    }
                }
                int totalCount = 0;
                int newPageIndex = -1;

                var rtnList = bs.GetProductListSp(filterString, sortString, request.PaginationRequest.PageIndex,
                                        request.PaginationRequest.PageSize, out totalCount, out newPageIndex);
                resp.Products.AddRange(rtnList);
                resp.TotalCount = totalCount;
                resp.newPageIndex = newPageIndex;
            }
            return resp;
        }

        //Usually not used.
        [Route("~/api/getproducts")]
        public IList<Models.ProductCM> GetAllProducts()
        {
            //IProductBS bs = default(IProductBS);
            IProductBS bs = DIFactoryDesigntime.GetInstance<IProductBS>();
            IList<Models.ProductCM> rtn = default(IList<Models.ProductCM>);
            //try
            //{
                rtn = bs.GetAllProductsByCategoryId(0);
            //}
            //catch (Exception ex)
            //{
            //    var msg = ex.Message;
            //}
            return rtn;
        }

        [Route("~/api/getallproducts")]
        public PagedProductListResponse GetAllProducts([ModelBinder(typeof(FieldValueModelBinder))] GetProductsBySearchRequest request)
        {
            var resp = new PagedProductListResponse();            
            int totalCount = 0;
            int newPageIndex = -1;

            IProductBS bs = DIFactoryDesigntime.GetInstance<IProductBS>();
            IList<Models.ProductCM> rtnList = bs.GetFullProducts(0, request.PaginationRequest, out totalCount, out newPageIndex);
            resp.Products.AddRange(rtnList);
            resp.TotalCount = totalCount;
            return resp;
        }

        [Route("~/api/getallproductsbycategoryid/{categoryId:int}")]
        public IList<Models.ProductCM> GetAllProductsByCategoryId(int categoryId)
        {
            //IProductBS bs = default(IProductBS);
            IProductBS bs = DIFactoryDesigntime.GetInstance<IProductBS>();
            return bs.GetAllProductsByCategoryId(categoryId);
        }

        [Route("{id:int}", Name = "GetProductById")]
        [ResponseType(typeof(Product))]
        public IHttpActionResult GetProductById(int id)
        {
            IProductBS bs = DIFactoryDesigntime.GetInstance<IProductBS>();
            var eProduct = bs.GetProductById(id);
            if (eProduct == null)
            {
                return NotFound();
            }
            else
            {
                IBaseConverter<Entities.Product, Models.Product> convtResult = new AutoMapConverter<Entities.Product, Models.Product>();
                Models.Product mProduct = convtResult.ConvertObject(eProduct);
                return Ok(mProduct);
            }
        }
        
        [Route("~/api/addproduct")]
        public AddProductResponse Post_AddProduct([FromBody] Models.Product mProduct)
        {
            IProductBS bs = DIFactoryDesigntime.GetInstance<IProductBS>();
            IBaseConverter<Models.Product, Entities.Product> convtResult = new AutoMapConverter<Models.Product, Entities.Product>();
            Entities.Product eProduct = convtResult.ConvertObject(mProduct);
            bs.AddProduct(eProduct);
            
            var addProductResponse = new AddProductResponse() 
            {
                ProductId =  eProduct.ProductId
            };
            return addProductResponse;  

            ////Generate a link to the new product and set the Location header in the response.
            ////For public HttpResponseMessage Post_AddProduct([FromBody] Models.Product mProduct)
            //var response = Request.CreateResponse(HttpStatusCode.Created);            
            //string uri = Url.Link("GetProductById", new { id = eProduct.ProductId });
            //response.Headers.Location = new Uri(uri);
            //return response;
        }

        [Route("~/api/updateproduct")]
        public void Post_UpdateProduct([FromBody] Models.Product mProduct)
        {
            IProductBS bs = DIFactoryDesigntime.GetInstance<IProductBS>();
            IBaseConverter<Models.Product, Entities.Product> convtResult = new AutoMapConverter<Models.Product, Entities.Product>();
            Entities.Product eProduct = convtResult.ConvertObject(mProduct);
            bs.UpdateProduct(eProduct);
        }

        [Route("~/api/deleteproduct")]
        public void DeleteProduct(int id)
        {
            IProductBS bs = DIFactoryDesigntime.GetInstance<IProductBS>();
            bs.DeleteProduct(id);
        }

        [Route("~/api/deleteproducts")]
        public void Post_DeleteProduct(List<int> ids)
        {
            IProductBS bs = DIFactoryDesigntime.GetInstance<IProductBS>();
            if (ids.Count > 0)
            {
                ids.ForEach(delegate(int id)
                {
                    bs.DeleteProduct(id);
                });
            }
        }        
    }
}
