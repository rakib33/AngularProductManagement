﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.ModelConfiguration.Conventions;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
//using System.Data.Entity.Core.Objects;
//using System.Data.Entity.Infrastructure;
using SM.Store.Api.Entities;

namespace SM.Store.Api.DAL
{
    public class StoreDataContext : DbContext
    {
        //public StoreDataContext()
        //    : base("name=StoreDataContext")
        public StoreDataContext(string connectionString)
            : base(connectionString)
        {
            this.Configuration.LazyLoadingEnabled = false;
            //if (HttpContext.Current != null)
            //{
            //    Database.SetInitializer<StoreDataContext>(new StoreDataContextInitializer());
            //}
        }

        public DbSet<Product> Products { get; set; }
        public DbSet<Category> Categories { get; set; }
        public DbSet<ProductStatusType> ProductStatusTypes { get; set; }
        public DbSet<Contact> Contacts { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Conventions.Remove<PluralizingTableNameConvention>();
        }

        public virtual List<Models.ProductCM> GetProductListSp(string filterString, string sortString, int pageNumber, int pageSize, out int totalCount)
        {
            filterString = filterString ?? string.Empty;
            var _filterString = new SqlParameter("@FilterString", filterString);

            sortString = sortString ?? string.Empty;
            var _sortString = new SqlParameter("@SortString", sortString);

            if (pageNumber == 0) pageNumber = 1;
            var _pageNumber = new SqlParameter("@PageNumber", pageNumber);
                        
            var _pageSize = new SqlParameter("@PageSize", pageSize);

            var _totalCount = new SqlParameter("@TotalCount", SqlDbType.Int);
            _totalCount.Direction = ParameterDirection.Output;

            var result = this.Database.SqlQuery<Models.ProductCM>("dbo.GetPagedProductList " +
                    "@FilterString, @SortString, @PageNumber, @PageSize, @TotalCount OUT",
                    _filterString, _sortString, _pageNumber, _pageSize, _totalCount).ToList();

            totalCount = (int)_totalCount.Value;
            return result;
        }
    }
}