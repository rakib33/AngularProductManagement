﻿'use strict';
var webApiBaseUrl = "http://localhost:20422/api/";

angular.module('smApp.dataServices', ['ngResource'])
//Web API call for product list.
.factory('productList', function ($resource) {
    return $resource(webApiBaseUrl + 'getproductlist?:params', {}, {
        query: {
            method: 'GET', isArray: false
        }
    });
})
//Web API call for product list by Post.
.factory('productList_p', function ($resource) {
    return $resource(webApiBaseUrl + 'getproductlist_p', {}, {
        post: {
            method: 'POST', isArray: false,
            headers: { 'Content-Type': 'application/json' }
        }
    });
})
//Web API call for product object.
.factory('productObj', function ($resource) {
    return $resource(webApiBaseUrl + 'products/:id', {}, {
        query: {
            method: 'GET', isArray: false
        }
    });
})
;

