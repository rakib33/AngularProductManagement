﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Http;
using System.IO;
using System.Text.Encodings.Web;
using Microsoft.AspNetCore.Diagnostics;
using Newtonsoft.Json.Serialization;
using Serilog;
using SM.Store.Api.DAL;
using SM.Store.Api.BLL;
using SM.Store.Api.Common;
using SM.Store.Api.Contracts.Configurations;
using SM.Store.Api.Contracts.Interfaces;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Server.IIS;
using System.Security.Claims;

namespace SM.Store.Api.Web
{
    public class Startup
    {
        //Core 3.0: replace IHostingEnvironment with IWebHostEnvironment. 
        readonly IWebHostEnvironment WebHostEnvironment;
        public IConfigurationRoot Configuration { get; }

        public Startup(IWebHostEnvironment env)
        {
            WebHostEnvironment = env;

            var builder = new ConfigurationBuilder()
                .SetBasePath(env.ContentRootPath)
                .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true)
                .AddJsonFile($"appsettings.{env.EnvironmentName}.json", optional: true)
                .AddEnvironmentVariables();

            Configuration = builder.Build();
        }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            //test
            //var ta = StaticConfigs.GetConfig("TestConfig1");
            var testValue = StaticConfigs.GetAppSetting("TestWebConfig");

            //Also make top level configuration available (for EF configuration and access to connection string)
            services.AddSingleton(Configuration); //IConfigurationRoot
            services.AddSingleton<IConfiguration>(Configuration);

            //Add Support for strongly typed Configuration and map to class
            services.AddOptions();
            services.Configure<AppConfig>(Configuration.GetSection("AppConfig"));

            //Set database.
            if (Configuration["AppConfig:UseInMemoryDatabase"] == "true")
            {
                services.AddDbContext<StoreDataContext>(opt => opt.UseInMemoryDatabase("StoreDbMemory"));
            }
            else
            {
                services.AddDbContext<StoreDataContext>(c =>
                    c.UseSqlServer(Configuration.GetConnectionString("StoreDbConnection")));
            }

            //Cors policy is added to controllers via [EnableCors("CorsPolicy")]
            //or .UseCors("CorsPolicy") globally
            services.AddCors(options =>
            {                
                options.AddPolicy("CorsPolicy",
                    builder => builder
                        .AllowAnyOrigin()
                        .AllowAnyMethod()
                        .AllowAnyHeader()
                        //.AllowCredentials() //Core 3.0 removed.
						);
            });

            //Instance injection
            services.AddScoped(typeof(IAutoMapConverter<,>), typeof(AutoMapConverter<,>));
            services.AddScoped(typeof(IGenericRepository<>), typeof(GenericRepository<>));
            services.AddScoped(typeof(IStoreLookupRepository<>), typeof(StoreLookupRepository<>));
            services.AddScoped<IProductRepository, ProductRepository>();
            services.AddScoped<IContactRepository, ContactRepository>();
            services.AddScoped<ILookupBS, LookupBS>();
            services.AddScoped<IProductBS, ProductBS>();
            services.AddScoped<IContactBS, ContactBS>();

            ////Per request injections
            //services.AddScoped<ApiExceptionFilter>();

            //Add framework services.
            //Core 3.0: change AddMvc to AddControllers.
            services.AddControllers(options => 
            {
                //options.Filters.Add(new ApiExceptionFilter());                
            })
            //Core 3.0: need to add Microsoft.AspNetCore.Mvc.NewtonsoftJson package and use AddNewtonsoftJson.
            .AddNewtonsoftJson(options =>
            {
                // Use the default property (Pascal) casing
                options.SerializerSettings.ContractResolver = new DefaultContractResolver();

                // Configure a custom converter
                //options.SerializerSettings.Converters.Add(new MyCustomJsonConverter());
            });

            //IIS in-process hosting.
            services.AddTransient<IClaimsTransformation, ClaimsTransformer>();
            services.AddAuthentication(IISServerDefaults.AuthenticationScheme);
        }

        //This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app,
            IWebHostEnvironment env,
            ILoggerFactory loggerFactory,
            IConfiguration configuration)
        {
            // Serilog config
            Log.Logger = new LoggerConfiguration()
                    .WriteTo.RollingFile(pathFormat: "logs\\log-{Date}.log")
                    .CreateLogger();

            //Core 3.0: need to add "using Microsoft.Extensions.Hosting;".
            if (env.IsDevelopment())
            {   
                loggerFactory.AddSerilog();
                app.UseDeveloperExceptionPage();
            }
            else
            {
                loggerFactory
                    .AddSerilog();
                app.UseExceptionHandler(errorApp =>

                    //Application level exception handler here - this is just a place holder
                    errorApp.Run(async (context) =>
                    {
                        context.Response.StatusCode = 500;
                        context.Response.ContentType = "text/html";
                        await context.Response.WriteAsync("<html><body>\r\n");
                        await context.Response.WriteAsync(
                                "We're sorry, we encountered an un-expected issue with your application.<br>\r\n");

                        //Capture the exception
                        var error = context.Features.Get<IExceptionHandlerFeature>();
                        if (error != null)
                        {
                            //This error would not normally be exposed to the client
                            await context.Response.WriteAsync("<br>Error: " +
                                    HtmlEncoder.Default.Encode(error.Error.Message) + "<br>\r\n");
                        }
                        await context.Response.WriteAsync("<br><a href=\"/\">Home</a><br>\r\n");
                        await context.Response.WriteAsync("</body></html>\r\n");
                        await context.Response.WriteAsync(new string(' ', 512)); // Padding for IE
                    }));
            }
            //Console.WriteLine("\r\nPlatform: " + System.Runtime.InteropServices.RuntimeInformation.OSDescription);
            //Console.WriteLine("DB Connection: "  + Configuration.GetConnectionString("StoreDbConnection"));

            //Core 3.0: need Microsoft.AspNetCore.Diagnostics.EntityFrameworkCore package.
            app.UseDatabaseErrorPage();
            
            app.UseStatusCodePages();
            app.UseStaticFiles();

            //index.html is not required
            //app.UseDefaultFiles();

            //Apply CORS.
            app.UseCors("CorsPolicy");

            //IIS in-process hosting.
            app.UseAuthentication();

            //put last so header configs like CORS or Cookies etc can fire
            //app.UseMvcWithDefaultRoute();
            //Core 3.0
            app.UseRouting();
            app.UseEndpoints(endpoints => endpoints.MapControllers());
        }
    }

    //IIS in-process hosting. 
    public class ClaimsTransformer : IClaimsTransformation
    {
        public Task<ClaimsPrincipal> TransformAsync(ClaimsPrincipal principal)
        {
            ((ClaimsIdentity)principal.Identity).AddClaim(new Claim("now", DateTime.Now.ToString()));
            return Task.FromResult(principal);
        }
    }
}
