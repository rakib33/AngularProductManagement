export enum Year {min = 1000, max = 9999}
