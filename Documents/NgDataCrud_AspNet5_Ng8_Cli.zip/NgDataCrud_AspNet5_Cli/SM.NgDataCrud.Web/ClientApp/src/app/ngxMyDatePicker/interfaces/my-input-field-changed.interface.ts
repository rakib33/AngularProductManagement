export interface IMyInputFieldChanged {
    value: string;
    dateFormat: string;
    valid: boolean;
}
